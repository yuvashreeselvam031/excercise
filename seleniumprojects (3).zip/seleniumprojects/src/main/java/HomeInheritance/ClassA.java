package HomeInheritance;

public class ClassA {

	public static void main(String[] args) {

		 
	}

}
