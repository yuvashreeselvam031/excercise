package assignment2;

public class Department extends College {

	public void departmentName() {

		System.out.println("departmentName: BCA");
	}
	

}
