package nov19;

public class Computer {

	public void computerModel() {

		System.out.println("computer model: lenova");
	}

}
