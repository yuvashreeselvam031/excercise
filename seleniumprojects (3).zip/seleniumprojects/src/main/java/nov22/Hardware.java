package nov22;

public interface Hardware {

	public  void hardwareResources();

}
