package nov22;

public interface Software {

	public void softwareResources();
}
